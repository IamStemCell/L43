from django.db import models
from django.urls import reverse

# Create your models here.
class Category(models.Model):
    title = models.CharField(max_length=100)


    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('category_detail', args=[str(self.id)])

class Note(models.Model):

    title = models.CharField(max_length=100)
    text = models.TextField()
    reminder = models.DateTimeField(null=True, blank=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)


    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('note_detail', args=[str(self.id)])