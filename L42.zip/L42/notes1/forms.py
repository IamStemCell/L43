from django import forms
from django.utils import timezone
from .models import Category, Note

class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ['title', 'text', 'reminder', 'category']

    def clean(self):
        cleaned_data = super().clean()
        reminder = cleaned_data.get('reminder')

        if reminder and reminder < timezone.now():
            raise forms.ValidationError("Reminder date must be in the future.")

        return cleaned_data


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['title']